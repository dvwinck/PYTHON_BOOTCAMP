from django.apps import AppConfig


class CoursesConfig(AppConfig):
    name = 'courses'
